# YTSpeedometer

A firefox extensions which allows the user to determine the playback speed of YouTube videos. The user can enter any number he likes and is not limited by the maximum 2-time speed from the YouTube ui.


